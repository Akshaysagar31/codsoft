const display = document.getElementById('display');
const buttons = document.querySelectorAll('button');

let currentInput = '';
let operator = '';
let operand1 = null;

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.textContent;

    if (!isNaN(value) || value === '.') {
      currentInput += value;
      display.value = currentInput;
    } else if (['+', '-', '*', '/'].includes(value)) {
      operator = value;
      operand1 = parseFloat(currentInput);
      currentInput = '';
    } else if (value === '=') {
      if (operator && operand1 !== null && currentInput !== '') {
        const operand2 = parseFloat(currentInput);
        let result = 0;
        switch (operator) {
          case '+': result = operand1 + operand2; break;
          case '-': result = operand1 - operand2; break;
          case '*': result = operand1 * operand2; break;
          case '/': result = operand2 !== 0 ? operand1 / operand2 : 'Error'; break;
        }
        display.value = result;
        currentInput = result.toString();
        operator = '';
        operand1 = null;
      }
    } else if (value === 'C') {
      currentInput = '';
      operator = '';
      operand1 = null;
      display.value = '';
    }
  });
});
